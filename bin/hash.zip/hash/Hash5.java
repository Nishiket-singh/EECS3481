package hash;

import java.math.BigInteger;

public class Hash5 {

	public static void main(String[] args) 
	{
		// 5a
		//probability of all birthdays being different
		// 1 - e^-(n^2/2(365))

		int x = 10;
		
		double s =1.0;
		
		for(int i =1; i< x; i++)
		{
			s *= (1.0 - (double)i/356) ;
		}
		
		double s2 = 1.0- Math.pow(Math.E, -Math.pow(x, 2.0)/(2.0 * 365));
	
		double x2 = 1.177*Math.sqrt(365);
		
		double s3 = 1.0- Math.pow(Math.E, -Math.pow(x2, 2.0)/(2.0 * 365));
		
		System.out.println(1.0-s);
	}

}
