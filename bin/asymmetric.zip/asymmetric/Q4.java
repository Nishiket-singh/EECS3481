package asymmetric;

import java.math.BigInteger;

public class Q4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BigInteger n = new BigInteger("1033931178476059651954862004553");
		BigInteger n_1 =  n.subtract(BigInteger.valueOf(1));

		//find k and m 
		BigInteger k = new BigInteger("1");
		BigInteger base = new BigInteger("2");
		BigInteger m = n_1.divide(base.pow(k.intValue()));
		
		while(true)
		{
			if( n_1.mod(base.pow(k.intValue()+1)) != BigInteger.valueOf(0))
				break;

			k = k.add(BigInteger.valueOf(1));
			m = n_1.divide(base.pow(k.intValue()));
			
		}
		
		System.out.print("m: "+m.toString()+"\n"+"k: "+k.toString()+"\n");

		BigInteger a = new BigInteger("2");
		BigInteger b0 = a.modPow(m, n);
			

		if( b0.equals(BigInteger.valueOf(1).mod(n)) || b0.equals(BigInteger.valueOf(-1).mod(n)))
		{
			System.out.println("probably prime");
		}
		else
		{
			boolean t = false;
			for(int i=0; i< k.intValue(); i++) 
			{
				BigInteger bNext = b0.modPow(base, n);				
				
				//System.out.println(bNext.toString());
				
				if( bNext.equals(BigInteger.valueOf(1).mod(n)) )   
				{
					System.out.println("Surely composite");
					t=true;
					break;
				}
				else if(bNext.equals(BigInteger.valueOf(-1).mod(n)))
				{
					System.out.println("probably prime");
					t=true;
					break;
				}
				
				
				b0 = bNext;

			}
			if(! t) System.out.print("inconclusive");
		}

	}

}
